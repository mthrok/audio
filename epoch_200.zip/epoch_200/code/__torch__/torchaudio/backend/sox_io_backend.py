def load(filepath: str,
    frame_offset: int=0,
    num_frames: int=-1,
    normalize: bool=True,
    channels_first: bool=True) -> Tuple[Tensor, int]:
  signal = ops.torchaudio.sox_io_load_audio_file(filepath, frame_offset, num_frames, normalize, channels_first)
  _0 = ((signal).get_tensor(), (signal).get_sample_rate())
  return _0
def save(filepath: str,
    src: Tensor,
    sample_rate: int,
    channels_first: bool=True,
    compression: Optional[float]=None) -> None:
  _1 = uninitialized(float)
  if torch.__is__(compression, None):
    _2 = (torch.split(filepath, ".", -1))[-1]
    ext = torch.lower(_2)
    _3 = torch.__contains__(["wav", "sph"], ext)
    if _3:
      compression1 = 0.
    else:
      if torch.eq(ext, "mp3"):
        compression2 = -4.5
      else:
        if torch.eq(ext, "flac"):
          compression3 = 8.
        else:
          _4 = torch.__contains__(["ogg", "vorbis"], ext)
          if _4:
            compression4 = 3.
          else:
            _5 = torch.format("Unsupported file type: \"{}\"", ext)
            ops.prim.RaiseException(_5)
            compression4 = _1
          compression3 = compression4
        compression2 = compression3
      compression1 = compression2
    compression0 = compression1
  else:
    compression0 = unchecked_cast(float, compression)
  signal = __torch__.torch.classes.torchaudio.TensorSignal.__new__(__torch__.torch.classes.torchaudio.TensorSignal)
  _6 = (signal).__init__(src, sample_rate, channels_first, )
  ops.torchaudio.sox_io_save_audio_file(filepath, signal, compression0)
  return None
