class ConvTasNet(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  num_sources : int
  enc_num_feats : int
  enc_kernel_size : int
  enc_stride : int
  encoder : __torch__.torch.nn.modules.conv.Conv1d
  mask_generator : __torch__.torchaudio.models.conv_tasnet.MaskGenerator
  decoder : __torch__.torch.nn.modules.conv.ConvTranspose1d
  def forward(self: __torch__.torchaudio.models.conv_tasnet.ConvTasNet,
    input: Tensor) -> Tensor:
    _0 = "Expected 3D tensor (batch, channel==1, frames). Found: {}"
    if torch.ne(torch.dim(input), 3):
      _1 = True
    else:
      _2 = torch.ne((torch.size(input))[1], 1)
      _1 = _2
    if _1:
      _3 = torch.format(_0, torch.size(input))
      ops.prim.RaiseException(_3)
    else:
      pass
    _4 = (self)._align_num_frames_with_strides(input, )
    padded, num_pads, = _4
    batch_size = (torch.size(padded))[0]
    num_padded_frames = (torch.size(padded))[2]
    feats = (self.encoder).forward(padded, )
    _5 = (self.mask_generator).forward(feats, )
    masked = torch.mul(_5, torch.unsqueeze(feats, 1))
    _6 = torch.mul(batch_size, self.num_sources)
    masked0 = torch.view(masked, [_6, self.enc_num_feats, -1])
    decoded = (self.decoder).forward(masked0, None, )
    _7 = [batch_size, self.num_sources, num_padded_frames]
    output = torch.view(decoded, _7)
    if torch.gt(num_pads, 0):
      output1 = torch.slice(output, -1, 0, torch.neg(num_pads), 1)
      output0 = output1
    else:
      output0 = output
    return output0
  def _align_num_frames_with_strides(self: __torch__.torchaudio.models.conv_tasnet.ConvTasNet,
    input: Tensor) -> Tuple[Tensor, int]:
    batch_size, num_channels, num_frames, = torch.size(input)
    is_odd = torch.remainder(self.enc_kernel_size, 2)
    num_strides = torch.floordiv(torch.sub(num_frames, is_odd), self.enc_stride)
    _8 = torch.mul(num_strides, self.enc_stride)
    num_remainings = torch.sub(num_frames, torch.add(is_odd, _8))
    if torch.eq(num_remainings, 0):
      _9 = (input, 0)
    else:
      num_paddings = torch.sub(self.enc_stride, num_remainings)
      _10 = ops.prim.dtype(input)
      _11 = ops.prim.device(input)
      _12 = [batch_size, num_channels, num_paddings]
      pad = torch.zeros(_12, dtype=_10, layout=None, device=_11, pin_memory=None)
      _13 = (torch.cat([input, pad], 2), num_paddings)
      _9 = _13
    return _9
class MaskGenerator(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  input_dim : int
  num_sources : int
  receptive_field : int
  input_norm : __torch__.torch.nn.modules.normalization.GroupNorm
  input_conv : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv1d
  conv_layers : __torch__.torch.nn.modules.container.ModuleList
  output_prelu : __torch__.torch.nn.modules.activation.PReLU
  output_conv : __torch__.torch.nn.modules.conv.___torch_mangle_25.Conv1d
  def forward(self: __torch__.torchaudio.models.conv_tasnet.MaskGenerator,
    input: Tensor) -> Tensor:
    batch_size = (torch.size(input))[0]
    feats = (self.input_norm).forward(input, )
    feats0 = (self.input_conv).forward(feats, )
    _14 = self.conv_layers
    _15 = getattr(_14, "0")
    _16 = getattr(_14, "1")
    _17 = getattr(_14, "2")
    _18 = getattr(_14, "3")
    _19 = getattr(_14, "4")
    _20 = getattr(_14, "5")
    _21 = getattr(_14, "6")
    _22 = getattr(_14, "7")
    _23 = getattr(_14, "8")
    _24 = getattr(_14, "9")
    _25 = getattr(_14, "10")
    _26 = getattr(_14, "11")
    _27 = getattr(_14, "12")
    _28 = getattr(_14, "13")
    _29 = getattr(_14, "14")
    _30 = getattr(_14, "15")
    _31 = getattr(_14, "16")
    _32 = getattr(_14, "17")
    _33 = getattr(_14, "18")
    _34 = getattr(_14, "19")
    _35 = getattr(_14, "20")
    _36 = getattr(_14, "21")
    _37 = getattr(_14, "22")
    _38 = getattr(_14, "23")
    residual, skip, = (_15).forward(feats0, )
    if torch.__isnot__(residual, None):
      residual0 = unchecked_cast(Tensor, residual)
      feats2 = torch.add(feats0, residual0, alpha=1)
      feats1 = feats2
    else:
      feats1 = feats0
    output = torch.add(skip, 0., 1)
    residual1, skip0, = (_16).forward(feats1, )
    if torch.__isnot__(residual1, None):
      residual2 = unchecked_cast(Tensor, residual1)
      feats4 = torch.add(feats1, residual2, alpha=1)
      feats3 = feats4
    else:
      feats3 = feats1
    output2 = torch.add(output, skip0, alpha=1)
    residual3, skip1, = (_17).forward(feats3, )
    if torch.__isnot__(residual3, None):
      residual4 = unchecked_cast(Tensor, residual3)
      feats6 = torch.add(feats3, residual4, alpha=1)
      feats5 = feats6
    else:
      feats5 = feats3
    output3 = torch.add(output2, skip1, alpha=1)
    residual5, skip2, = (_18).forward(feats5, )
    if torch.__isnot__(residual5, None):
      residual6 = unchecked_cast(Tensor, residual5)
      feats8 = torch.add(feats5, residual6, alpha=1)
      feats7 = feats8
    else:
      feats7 = feats5
    output4 = torch.add(output3, skip2, alpha=1)
    residual7, skip3, = (_19).forward(feats7, )
    if torch.__isnot__(residual7, None):
      residual8 = unchecked_cast(Tensor, residual7)
      feats10 = torch.add(feats7, residual8, alpha=1)
      feats9 = feats10
    else:
      feats9 = feats7
    output5 = torch.add(output4, skip3, alpha=1)
    residual9, skip4, = (_20).forward(feats9, )
    if torch.__isnot__(residual9, None):
      residual10 = unchecked_cast(Tensor, residual9)
      feats12 = torch.add(feats9, residual10, alpha=1)
      feats11 = feats12
    else:
      feats11 = feats9
    output6 = torch.add(output5, skip4, alpha=1)
    residual11, skip5, = (_21).forward(feats11, )
    if torch.__isnot__(residual11, None):
      residual12 = unchecked_cast(Tensor, residual11)
      feats14 = torch.add(feats11, residual12, alpha=1)
      feats13 = feats14
    else:
      feats13 = feats11
    output7 = torch.add(output6, skip5, alpha=1)
    residual13, skip6, = (_22).forward(feats13, )
    if torch.__isnot__(residual13, None):
      residual14 = unchecked_cast(Tensor, residual13)
      feats16 = torch.add(feats13, residual14, alpha=1)
      feats15 = feats16
    else:
      feats15 = feats13
    output8 = torch.add(output7, skip6, alpha=1)
    residual15, skip7, = (_23).forward(feats15, )
    if torch.__isnot__(residual15, None):
      residual16 = unchecked_cast(Tensor, residual15)
      feats18 = torch.add(feats15, residual16, alpha=1)
      feats17 = feats18
    else:
      feats17 = feats15
    output9 = torch.add(output8, skip7, alpha=1)
    residual17, skip8, = (_24).forward(feats17, )
    if torch.__isnot__(residual17, None):
      residual18 = unchecked_cast(Tensor, residual17)
      feats20 = torch.add(feats17, residual18, alpha=1)
      feats19 = feats20
    else:
      feats19 = feats17
    output10 = torch.add(output9, skip8, alpha=1)
    residual19, skip9, = (_25).forward(feats19, )
    if torch.__isnot__(residual19, None):
      residual20 = unchecked_cast(Tensor, residual19)
      feats22 = torch.add(feats19, residual20, alpha=1)
      feats21 = feats22
    else:
      feats21 = feats19
    output11 = torch.add(output10, skip9, alpha=1)
    residual21, skip10, = (_26).forward(feats21, )
    if torch.__isnot__(residual21, None):
      residual22 = unchecked_cast(Tensor, residual21)
      feats24 = torch.add(feats21, residual22, alpha=1)
      feats23 = feats24
    else:
      feats23 = feats21
    output12 = torch.add(output11, skip10, alpha=1)
    residual23, skip11, = (_27).forward(feats23, )
    if torch.__isnot__(residual23, None):
      residual24 = unchecked_cast(Tensor, residual23)
      feats26 = torch.add(feats23, residual24, alpha=1)
      feats25 = feats26
    else:
      feats25 = feats23
    output13 = torch.add(output12, skip11, alpha=1)
    residual25, skip12, = (_28).forward(feats25, )
    if torch.__isnot__(residual25, None):
      residual26 = unchecked_cast(Tensor, residual25)
      feats28 = torch.add(feats25, residual26, alpha=1)
      feats27 = feats28
    else:
      feats27 = feats25
    output14 = torch.add(output13, skip12, alpha=1)
    residual27, skip13, = (_29).forward(feats27, )
    if torch.__isnot__(residual27, None):
      residual28 = unchecked_cast(Tensor, residual27)
      feats30 = torch.add(feats27, residual28, alpha=1)
      feats29 = feats30
    else:
      feats29 = feats27
    output15 = torch.add(output14, skip13, alpha=1)
    residual29, skip14, = (_30).forward(feats29, )
    if torch.__isnot__(residual29, None):
      residual30 = unchecked_cast(Tensor, residual29)
      feats32 = torch.add(feats29, residual30, alpha=1)
      feats31 = feats32
    else:
      feats31 = feats29
    output16 = torch.add(output15, skip14, alpha=1)
    residual31, skip15, = (_31).forward(feats31, )
    if torch.__isnot__(residual31, None):
      residual32 = unchecked_cast(Tensor, residual31)
      feats34 = torch.add(feats31, residual32, alpha=1)
      feats33 = feats34
    else:
      feats33 = feats31
    output17 = torch.add(output16, skip15, alpha=1)
    residual33, skip16, = (_32).forward(feats33, )
    if torch.__isnot__(residual33, None):
      residual34 = unchecked_cast(Tensor, residual33)
      feats36 = torch.add(feats33, residual34, alpha=1)
      feats35 = feats36
    else:
      feats35 = feats33
    output18 = torch.add(output17, skip16, alpha=1)
    residual35, skip17, = (_33).forward(feats35, )
    if torch.__isnot__(residual35, None):
      residual36 = unchecked_cast(Tensor, residual35)
      feats38 = torch.add(feats35, residual36, alpha=1)
      feats37 = feats38
    else:
      feats37 = feats35
    output19 = torch.add(output18, skip17, alpha=1)
    residual37, skip18, = (_34).forward(feats37, )
    if torch.__isnot__(residual37, None):
      residual38 = unchecked_cast(Tensor, residual37)
      feats40 = torch.add(feats37, residual38, alpha=1)
      feats39 = feats40
    else:
      feats39 = feats37
    output20 = torch.add(output19, skip18, alpha=1)
    residual39, skip19, = (_35).forward(feats39, )
    if torch.__isnot__(residual39, None):
      residual40 = unchecked_cast(Tensor, residual39)
      feats42 = torch.add(feats39, residual40, alpha=1)
      feats41 = feats42
    else:
      feats41 = feats39
    output21 = torch.add(output20, skip19, alpha=1)
    residual41, skip20, = (_36).forward(feats41, )
    if torch.__isnot__(residual41, None):
      residual42 = unchecked_cast(Tensor, residual41)
      feats44 = torch.add(feats41, residual42, alpha=1)
      feats43 = feats44
    else:
      feats43 = feats41
    output22 = torch.add(output21, skip20, alpha=1)
    residual43, skip21, = (_37).forward(feats43, )
    if torch.__isnot__(residual43, None):
      residual44 = unchecked_cast(Tensor, residual43)
      feats46 = torch.add(feats43, residual44, alpha=1)
      feats45 = feats46
    else:
      feats45 = feats43
    output23 = torch.add(output22, skip21, alpha=1)
    residual45, skip22, = (_38).forward(feats45, )
    output24 = torch.add(output23, skip22, alpha=1)
    output25 = (self.output_prelu).forward(output24, )
    output26 = (self.output_conv).forward(output25, )
    output27 = torch.sigmoid(output26)
    _39 = [batch_size, self.num_sources, self.input_dim, -1]
    return torch.view(output27, _39)
class ConvBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  conv_layers : __torch__.torch.nn.modules.container.Sequential
  res_out : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv1d
  skip_out : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv1d
  def forward(self: __torch__.torchaudio.models.conv_tasnet.ConvBlock,
    input: Tensor) -> Tuple[Optional[Tensor], Tensor]:
    feature = (self.conv_layers).forward(input, )
    residual = (self.res_out).forward(feature, )
    skip_out = (self.skip_out).forward(feature, )
    return (residual, skip_out)
