def group_norm(input: Tensor,
    num_groups: int,
    weight: Optional[Tensor]=None,
    bias: Optional[Tensor]=None,
    eps: float=1.0000000000000001e-05) -> Tensor:
  _0 = __torch__.torch.nn.functional._verify_batch_size
  _1 = torch.mul(torch.size(input, 0), torch.size(input, 1))
  _2 = [torch.floordiv(_1, num_groups), num_groups]
  _3 = torch.slice(torch.size(input), 2, 9223372036854775807, 1)
  _4 = _0(torch.add(_2, torch.list(_3)), )
  _5 = torch.group_norm(input, num_groups, weight, bias, eps, True)
  return _5
def prelu(input: Tensor,
    weight: Tensor) -> Tensor:
  return torch.prelu(input, weight)
def _verify_batch_size(size: List[int]) -> None:
  _6 = "Expected more than 1 value per channel when training, got input size {}"
  size_prods = size[0]
  size_prods0 = size_prods
  for i in range(torch.sub(torch.len(size), 2)):
    size_prods1 = torch.mul(size_prods0, size[torch.add(i, 2)])
    size_prods0 = size_prods1
  if torch.eq(size_prods0, 1):
    ops.prim.RaiseException(torch.format(_6, size))
  else:
    pass
  return None
