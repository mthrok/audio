class SourceSeparationPipeline(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  sample_rate : int
  conv_tasnet : __torch__.torchaudio.models.conv_tasnet.ConvTasNet
  def forward(self: __torch__.SourceSeparationPipeline,
    input_path: str,
    output_path: str) -> None:
    _0 = __torch__.torchaudio.backend.sox_io_backend.load
    _1 = __torch__.torchaudio.backend.sox_io_backend.save
    data, sample_rate, = _0(input_path, 0, -1, True, True, )
    _2 = torch.eq(sample_rate, self.sample_rate)
    if _2:
      pass
    else:
      ops.prim.RaiseException("AssertionError: ")
    _3 = (self.conv_tasnet).forward(torch.unsqueeze(data, 0), )
    output = torch.squeeze(_3, 0)
    _4 = _1(output_path, output, self.sample_rate, True, None, )
    return None
