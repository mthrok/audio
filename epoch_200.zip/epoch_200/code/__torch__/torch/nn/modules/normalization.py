class GroupNorm(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = []
  weight : Tensor
  bias : Tensor
  training : bool
  affine : Final[bool] = True
  eps : Final[float] = 1e-08
  num_groups : Final[int] = 1
  num_channels : Final[int] = 512
  def forward(self: __torch__.torch.nn.modules.normalization.GroupNorm,
    input: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.group_norm
    _1 = _0(input, 1, self.weight, self.bias, 1e-08, )
    return _1
