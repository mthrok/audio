class ConvBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  conv_layers : __torch__.torch.nn.modules.container.___torch_mangle_4.Sequential
  res_out : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv1d
  skip_out : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv1d
  def forward(self: __torch__.torchaudio.models.conv_tasnet.___torch_mangle_5.ConvBlock,
    input: Tensor) -> Tuple[Optional[Tensor], Tensor]:
    feature = (self.conv_layers).forward(input, )
    residual = (self.res_out).forward(feature, )
    skip_out = (self.skip_out).forward(feature, )
    return (residual, skip_out)
