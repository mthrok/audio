class PReLU(Module):
  __parameters__ = ["weight", ]
  __buffers__ = []
  weight : Tensor
  training : bool
  num_parameters : Final[int] = 1
  def forward(self: __torch__.torch.nn.modules.activation.PReLU,
    input: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.prelu(input, self.weight, )
    return _0
