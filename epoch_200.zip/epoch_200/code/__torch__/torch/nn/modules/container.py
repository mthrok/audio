class ModuleList(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  __annotations__["0"] = __torch__.torchaudio.models.conv_tasnet.ConvBlock
  __annotations__["1"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_5.ConvBlock
  __annotations__["2"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_8.ConvBlock
  __annotations__["3"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_11.ConvBlock
  __annotations__["4"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_14.ConvBlock
  __annotations__["5"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_17.ConvBlock
  __annotations__["6"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_20.ConvBlock
  __annotations__["7"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_23.ConvBlock
  __annotations__["8"] = __torch__.torchaudio.models.conv_tasnet.ConvBlock
  __annotations__["9"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_5.ConvBlock
  __annotations__["10"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_8.ConvBlock
  __annotations__["11"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_11.ConvBlock
  __annotations__["12"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_14.ConvBlock
  __annotations__["13"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_17.ConvBlock
  __annotations__["14"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_20.ConvBlock
  __annotations__["15"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_23.ConvBlock
  __annotations__["16"] = __torch__.torchaudio.models.conv_tasnet.ConvBlock
  __annotations__["17"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_5.ConvBlock
  __annotations__["18"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_8.ConvBlock
  __annotations__["19"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_11.ConvBlock
  __annotations__["20"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_14.ConvBlock
  __annotations__["21"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_17.ConvBlock
  __annotations__["22"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_20.ConvBlock
  __annotations__["23"] = __torch__.torchaudio.models.conv_tasnet.___torch_mangle_24.ConvBlock
  def forward(self: __torch__.torch.nn.modules.container.ModuleList) -> None:
    _0 = uninitialized(None)
    ops.prim.RaiseException("")
    return _0
  def __len__(self: __torch__.torch.nn.modules.container.ModuleList) -> int:
    return 24
class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  __annotations__["0"] = __torch__.torch.nn.modules.conv.___torch_mangle_1.Conv1d
  __annotations__["1"] = __torch__.torch.nn.modules.activation.PReLU
  __annotations__["2"] = __torch__.torch.nn.modules.normalization.GroupNorm
  __annotations__["3"] = __torch__.torch.nn.modules.conv.___torch_mangle_2.Conv1d
  __annotations__["4"] = __torch__.torch.nn.modules.activation.PReLU
  __annotations__["5"] = __torch__.torch.nn.modules.normalization.GroupNorm
  def forward(self: __torch__.torch.nn.modules.container.Sequential,
    input: Tensor) -> Tensor:
    _1 = getattr(self, "0")
    _2 = getattr(self, "1")
    _3 = getattr(self, "2")
    _4 = getattr(self, "3")
    _5 = getattr(self, "4")
    _6 = getattr(self, "5")
    input0 = (_1).forward(input, )
    input1 = (_2).forward(input0, )
    input2 = (_3).forward(input1, )
    input3 = (_4).forward(input2, )
    input4 = (_5).forward(input3, )
    return (_6).forward(input4, )
  def __len__(self: __torch__.torch.nn.modules.container.Sequential) -> int:
    return 6
