class Conv1d(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = []
  weight : Tensor
  bias : Optional[Tensor]
  training : bool
  transposed : bool
  _reversed_padding_repeated_twice : Tuple[int, int]
  out_channels : Final[int] = 512
  kernel_size : Final[Tuple[int]] = (3,)
  in_channels : Final[int] = 512
  output_padding : Final[Tuple[int]] = (0,)
  dilation : Final[Tuple[int]] = (16,)
  stride : Final[Tuple[int]] = (1,)
  padding : Final[Tuple[int]] = (16,)
  groups : Final[int] = 512
  padding_mode : Final[str] = "zeros"
  def forward(self: __torch__.torch.nn.modules.conv.___torch_mangle_12.Conv1d,
    input: Tensor) -> Tensor:
    _0 = torch.conv1d(input, self.weight, self.bias, [1], [16], [16], 512)
    return _0
