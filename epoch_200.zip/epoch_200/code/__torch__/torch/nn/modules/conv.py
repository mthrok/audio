class Conv1d(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = []
  weight : Tensor
  bias : Optional[Tensor]
  training : bool
  transposed : bool
  _reversed_padding_repeated_twice : Tuple[int, int]
  out_channels : Final[int] = 512
  kernel_size : Final[Tuple[int]] = (16,)
  in_channels : Final[int] = 1
  output_padding : Final[Tuple[int]] = (0,)
  dilation : Final[Tuple[int]] = (1,)
  stride : Final[Tuple[int]] = (8,)
  padding : Final[Tuple[int]] = (8,)
  groups : Final[int] = 1
  padding_mode : Final[str] = "zeros"
  def forward(self: __torch__.torch.nn.modules.conv.Conv1d,
    input: Tensor) -> Tensor:
    _0 = torch.conv1d(input, self.weight, self.bias, [8], [8], [1], 1)
    return _0
class ConvTranspose1d(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = []
  weight : Tensor
  bias : Optional[Tensor]
  training : bool
  transposed : bool
  _reversed_padding_repeated_twice : Tuple[int, int]
  out_channels : Final[int] = 1
  kernel_size : Final[Tuple[int]] = (16,)
  in_channels : Final[int] = 512
  output_padding : Final[Tuple[int]] = (0,)
  dilation : Final[Tuple[int]] = (1,)
  stride : Final[Tuple[int]] = (8,)
  padding : Final[Tuple[int]] = (8,)
  groups : Final[int] = 1
  padding_mode : Final[str] = "zeros"
  def forward(self: __torch__.torch.nn.modules.conv.ConvTranspose1d,
    input: Tensor,
    output_size: Optional[List[int]]=None) -> Tensor:
    output_padding = (self)._output_padding(input, output_size, [8], [8], [16], [1], )
    _1 = torch.conv_transpose1d(input, self.weight, self.bias, [8], [8], output_padding, 1, [1])
    return _1
  def _output_padding(self: __torch__.torch.nn.modules.conv.ConvTranspose1d,
    input: Tensor,
    output_size: Optional[List[int]],
    stride: List[int],
    padding: List[int],
    kernel_size: List[int],
    dilation: Optional[List[int]]=None) -> List[int]:
    _2 = "output_size must have {} or {} elements (got {})"
    _3 = "requested an output size of {}, but valid sizes range from {} to {} (for an input of {})"
    if torch.__is__(output_size, None):
      ret = [0]
    else:
      output_size0 = unchecked_cast(List[int], output_size)
      k = torch.sub(torch.dim(input), 2)
      _4 = torch.eq(torch.len(output_size0), torch.add(k, 2))
      if _4:
        output_size2 = torch.slice(output_size0, 2, 9223372036854775807, 1)
        output_size1 = output_size2
      else:
        output_size1 = output_size0
      _5 = torch.ne(torch.len(output_size1), k)
      if _5:
        _6 = torch.format(_2, k, torch.add(k, 2), torch.len(output_size1))
        ops.prim.RaiseException(_6)
      else:
        pass
      min_sizes = annotate(List[int], [])
      max_sizes = annotate(List[int], [])
      dilation0 = dilation
      for d in range(k):
        _7 = torch.size(input, torch.add(d, 2))
        _8 = torch.mul(torch.sub(_7, 1), stride[d])
        _9 = torch.sub(_8, torch.mul(2, padding[d]))
        _10 = torch.__isnot__(dilation0, None)
        if _10:
          dilation2 = unchecked_cast(List[int], dilation0)
          _11, dilation1 = dilation2[d], dilation2
        else:
          _11, dilation1 = 1, dilation0
        _12 = torch.mul(_11, torch.sub(kernel_size[d], 1))
        dim_size = torch.add(torch.add(_9, _12), 1)
        _13 = torch.append(min_sizes, dim_size)
        _14 = torch.add(min_sizes[d], stride[d])
        _15 = torch.append(max_sizes, torch.sub(_14, 1))
        dilation0 = dilation1
      for i in range(torch.len(output_size1)):
        size = output_size1[i]
        min_size = min_sizes[i]
        max_size = max_sizes[i]
        if torch.lt(size, min_size):
          _16 = True
        else:
          _16 = torch.gt(size, max_size)
        if _16:
          _17 = torch.slice(torch.size(input), 2, 9223372036854775807, 1)
          _18 = torch.format(_3, output_size1, min_sizes, max_sizes, _17)
          ops.prim.RaiseException(_18)
        else:
          pass
      res = annotate(List[int], [])
      for d0 in range(k):
        _19 = torch.sub(output_size1[d0], min_sizes[d0])
        _20 = torch.append(res, _19)
      ret = res
    return ret
